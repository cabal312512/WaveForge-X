Recorded synthetic receiver study. See docs/reproduce.md and docs/research.md in WaveForge-X.
Original internal phase IDs are retained only in provenance. Outputs are not experimental reruns.
